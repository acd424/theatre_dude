import Head from 'next/head';
import Link from 'next/link';
import Navigation from '../components/Navigation';
import styles from '../styles/Home.module.css';

export default function Home() {
  return (
    <>
      <Head>
        <title>Theatre Dude - Conway's Reel Time</title>
        <meta name="description" content="Incredible improv, theatre, and exclusive merchandise" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>

      <Navigation />

      <main className={styles.main}>
        <section className={styles.hero}>
          <div className={styles.heroContent}>
            <div className={styles.logoContainer}>
              <img 
                src="/theatre-dude-logo.png" 
                alt="Theatre Dude Productions" 
                className={styles.mainLogo}
              />
            </div>
            <p className={styles.heroSubtitle}>
              Welcome to Conway's Reel Time! Experience incredible improv performances, theatre productions, and exclusive autographed merchandise from your favorite shows.
            </p>
            <div className={styles.heroButtons}>
              <Link href="/listen" className={styles.btnPrimary}>
                Start Watching
              </Link>
              <Link href="/store" className={styles.btnSecondary}>
                Browse Store
              </Link>
            </div>
          </div>
          
          <div className={styles.heroVisual}>
            <div className={styles.visualCircle}></div>
            <div className={styles.visualText}>THEATRE</div>
          </div>
        </section>

        <section className={styles.features}>
          <div className={styles.feature}>
            <div className={styles.featureIcon}>🎭</div>
            <h3 className={styles.featureTitle}>INCREDIBLE IMPROV</h3>
            <p className={styles.featureDesc}>
              Hilarious improvised performances and exclusive playlists
            </p>
          </div>
          
          <div className={styles.feature}>
            <div className={styles.featureIcon}>🎬</div>
            <h3 className={styles.featureTitle}>THEATRE PRODUCTIONS</h3>
            <p className={styles.featureDesc}>
              Watch Little Mermaids Jr and other amazing shows
            </p>
          </div>
          
          <div className={styles.feature}>
            <div className={styles.featureIcon}>✍️</div>
            <h3 className={styles.featureTitle}>AUTOGRAPHED MERCH</h3>
            <p className={styles.featureDesc}>
              Exclusive signed items and theatre dude merchandise
            </p>
          </div>
        </section>
      </main>
    </>
  );
}
